/*
 * Copyright (c) 2016
 *	ASST2 task3
 */


#include <types.h>
#include <lib.h>

void hello(void);

void
hello(void)
{
	kprintf("Hello World\n");
}
