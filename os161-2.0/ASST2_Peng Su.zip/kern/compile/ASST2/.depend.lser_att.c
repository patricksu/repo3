lser_att.o: ../../dev/lamebus/lser_att.c ../../include/types.h \
  ../../include/kern/types.h includelinks/kern/machine/types.h \
  includelinks/machine/types.h ../../include/lib.h ../../include/cdefs.h \
  opt-noasserts.h ../../dev/lamebus/lamebus.h ../../include/cpu.h \
  ../../include/spinlock.h includelinks/machine/spinlock.h \
  ../../include/threadlist.h includelinks/machine/vm.h \
  ../../dev/lamebus/lser.h autoconf.h
